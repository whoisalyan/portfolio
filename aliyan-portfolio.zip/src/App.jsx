import React, { useState } from 'react';

const App = () => {
  const [status, setStatus] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('Sending...');

    const form = new FormData(e.target);
    const response = await fetch('https://formspree.io/f/xeozzawj', {
      method: 'POST',
      body: form,
      headers: {
        Accept: 'application/json',
      },
    });

    if (response.ok) {
      setStatus('Message sent!');
      e.target.reset();
    } else {
      setStatus('Failed to send.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Aliyan Abbasi</h1>
        <p className="mb-6">Software Developer | Python | Flask | Salesforce | CRM | Cybersecurity</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input name="name" placeholder="Your Name" className="w-full p-2 bg-gray-800 border border-gray-700 rounded" required />
          <input name="email" placeholder="Your Email" type="email" className="w-full p-2 bg-gray-800 border border-gray-700 rounded" required />
          <textarea name="message" placeholder="Your Message" rows="4" className="w-full p-2 bg-gray-800 border border-gray-700 rounded" required />
          <button type="submit" className="bg-blue-600 px-4 py-2 rounded">Send</button>
        </form>
        <p className="mt-2">{status}</p>
      </div>
    </div>
  );
};

export default App;